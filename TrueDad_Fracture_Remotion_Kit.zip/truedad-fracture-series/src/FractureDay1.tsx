import React from 'react';
import {AbsoluteFill, Audio, Img, OffthreadVideo, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import day from '../data/day01.json';

// This is a functional visual starter, NOT the final edit. Claude must sync actual
// voiceover words, build proof-grade shots and deliver a fully rendered master.
const C={bg:'#0B0E13',surface:'#151A22',line:'#2B3440',gold:'#D9A93D',white:'#F4F1E9',muted:'#98A3B5',red:'#E54C58'};
const uiFont='Arial, Helvetica, sans-serif';
const monoFont='"Courier New", monospace';

const easeUp = (f:number)=>interpolate(f,[0,12],[48,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
const reveal = (f:number)=>interpolate(f,[0,12],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});

const Eyebrow:React.FC<{children:React.ReactNode}>=({children})=>(
  <div style={{color:C.gold, fontFamily:monoFont,fontSize:27,letterSpacing:3,fontWeight:'bold',marginBottom:26}}>{children}</div>
);
const Big:React.FC<{children:React.ReactNode,color?:string,size?:number}>=({children,color=C.white,size=106})=>(
  <div style={{fontSize:size,color,fontWeight:900,fontFamily:uiFont,letterSpacing:-4,lineHeight:1.02}}>{children}</div>
);
const Panel:React.FC<{children:React.ReactNode, style?:React.CSSProperties}>=({children,style})=>(
  <div style={{border:`1.5px solid ${C.line}`,borderRadius:24,background:'rgba(21,26,34,0.92)',padding:33,boxShadow:'0 22px 60px rgba(0,0,0,.22)',...style}}>{children}</div>
);
const Header:React.FC=()=> (
  <div style={{position:'absolute',top:125,left:74,right:74,zIndex:20,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
    <div style={{color:C.white, fontWeight:900,fontSize:28,letterSpacing:2}}>TRUE<span style={{color:C.gold}}>DAD</span></div>
    <div style={{color:C.muted,fontFamily:monoFont,fontSize:22}}>CS2 / INVESTING</div>
  </div>
);
const GridBg:React.FC=()=> (
  <AbsoluteFill style={{background:`radial-gradient(circle at 95% 6%, #24232A 0%, transparent 45%), ${C.bg}`}}>
    <div style={{position:'absolute',inset:0,opacity:.16,backgroundImage:'linear-gradient(#4E5B70 1px,transparent 1px),linear-gradient(90deg,#4E5B70 1px,transparent 1px)',backgroundSize:'90px 90px'}}/>
    <div style={{position:'absolute',left:76,top:196,bottom:200,width:3,background:`linear-gradient(${C.gold},transparent)`,opacity:.45}}/>
  </AbsoluteFill>
);
const Market:React.FC=()=>{
  const f=useCurrentFrame();
  const transitionY=easeUp(f), alpha=reveal(f);
  return <AbsoluteFill style={{padding:'290px 74px 275px',opacity:alpha,transform:`translateY(${transitionY}px)`}}>
    <Eyebrow>DAY 01 / MARKET FALL</Eyebrow>
    <Big>РЫНОК</Big><Big color={C.red}>ПАДАЕТ.</Big>
    <div style={{fontSize:46,fontWeight:800,color:C.white,marginTop:22}}>Я продолжаю покупать.</div>
    <Panel style={{marginTop:85,height:570,overflow:'hidden',position:'relative'}}>
      <div style={{color:C.muted,fontSize:23,fontFamily:monoFont,marginBottom:15}}>FRACTURE CASE / STEAM MARKET</div>
      <OffthreadVideo src={staticFile('assets/footage-curated.mp4')} startFrom={Math.round(12*24)} style={{position:'absolute',width:1580,height:890,left:-342,top:64,objectFit:'cover',opacity:.85}} muted />
      <div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,rgba(11,14,19,.1) 40%,rgba(11,14,19,.88) 100%)',pointerEvents:'none'}}/>
    </Panel>
    <div style={{fontSize:29,color:C.muted,marginTop:42}}>30 дней инвестэксперимента</div>
  </AbsoluteFill>;
};
const Plan:React.FC=()=>{
  const f=useCurrentFrame();const p=spring({fps:30,frame:f,config:{damping:200}});
  return <AbsoluteFill style={{padding:'310px 74px 230px'}}>
    <Eyebrow>ПРАВИЛА / 30 DAYS</Eyebrow>
    <Big size={91}>КАЖДЫЙ ДЕНЬ</Big>
    <Big color={C.gold} size={91}>НА 5 БОЛЬШЕ</Big>
    <div style={{fontSize:33,color:C.muted,marginTop:38}}>Количество кейсов в день</div>
    <div style={{display:'flex',alignItems:'center',gap:17,marginTop:100}}>
      {[20,25,30,165].map((n,i)=><React.Fragment key={n}>{i>0&&<div style={{color:C.muted,fontSize:29}}>›</div>}<Panel style={{flex:1,padding:'27px 13px',textAlign:'center',borderColor:i===3?C.gold:C.line,transform:`scale(${.92+.08*p})`}}><div style={{color:i===3?C.gold:C.white,fontSize:44,fontFamily:monoFont,fontWeight:800}}>{n}</div></Panel></React.Fragment>)}
    </div>
    <Panel style={{marginTop:65,padding:44}}><div style={{color:C.muted,fontSize:25}}>ЦЕЛЬ ПО ИТОГАМ МЕСЯЦА</div><Big color={C.gold} size={138}>{day.monthlyTargetCases.toLocaleString('ru-RU')}</Big><div style={{color:C.white,fontSize:28}}>КЕЙСОВ В ИНВЕНТАРЕ</div></Panel>
  </AbsoluteFill>;
};
const Evidence:React.FC=()=>{
 const f=useCurrentFrame();
 return <AbsoluteFill style={{padding:'300px 74px 240px'}}>
   <Eyebrow>FRACTURE CASE / REAL PURCHASE</Eyebrow><Big size={91}>ПЕРВАЯ</Big><Big color={C.gold} size={91}>ЗАКУПКА</Big>
   <Panel style={{marginTop:55,height:800,overflow:'hidden',position:'relative',padding:0}}>
     <Img src={staticFile('assets/proof/inventory_20.jpg')} style={{width:'100%',height:'100%',objectFit:'cover',opacity:.9,transform:`scale(${1.02+Math.min(f/400,.15)})`}}/>
   </Panel>
   <Panel style={{position:'absolute',left:118,right:118,bottom:240,padding:35}}>
     <div style={{fontSize:24,color:C.muted,fontFamily:monoFont}}>ПОДТВЕРЖДЕНО В ИНВЕНТАРЕ</div>
     <Big size={110} color={C.gold}>20 КЕЙСОВ</Big>
   </Panel>
 </AbsoluteFill>;
};
const Outro:React.FC=()=>{
  const f=useCurrentFrame();const a=reveal(f);
  return <AbsoluteFill style={{padding:'320px 74px 265px',opacity:a}}>
    <Eyebrow>EXPERIMENT / DAY 01</Eyebrow>
    <Big size={115}>20 / 2775</Big>
    <div style={{marginTop:27,color:C.muted,fontSize:33}}>ПЕРВЫЙ ДЕНЬ ЗАВЕРШЁН</div>
    <Panel style={{marginTop:95,borderColor:C.gold}}>
      <div style={{color:C.muted,fontSize:28}}>ЗАВТРА КУПЛЮ</div><Big color={C.gold} size={149}>25</Big><div style={{color:C.white,fontSize:31}}>КЕЙСОВ</div>
    </Panel>
    <div style={{marginTop:95,color:C.white,fontWeight:900,fontSize:64}}>ГЕНИЙ ИЛИ ДУРАК?</div>
    <div style={{color:C.muted,fontSize:30,marginTop:22}}>Напиши свой прогноз.</div>
  </AbsoluteFill>;
};

export const FractureDay1:React.FC=()=>{
  const frame=useCurrentFrame(); const cfg=useVideoConfig();
  return <AbsoluteFill style={{background:C.bg,overflow:'hidden'}}>
    <GridBg/><Header/>
    <Sequence from={0} durationInFrames={245}><Market/></Sequence>
    <Sequence from={245} durationInFrames={530}><Plan/></Sequence>
    <Sequence from={775} durationInFrames={440}><Evidence/></Sequence>
    <Sequence from={1215} durationInFrames={107}><Outro/></Sequence>
    <div style={{position:'absolute',left:74,right:74,bottom:160,height:3,background:C.line}}>
      <div style={{height:'100%',width:`${(frame+1)/cfg.durationInFrames*100}%`,background:C.gold}}/>
    </div>
    <Audio src={staticFile('assets/voiceover-day01.mp3')} />
  </AbsoluteFill>;
};
