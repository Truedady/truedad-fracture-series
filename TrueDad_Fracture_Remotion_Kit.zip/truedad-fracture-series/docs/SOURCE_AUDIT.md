# Material audit / 2026-10-20

## Original uploaded assets

- `1020 (1).mp4`: **102.400s**, 2560x1440, H.264, 30fps, with desktop AAC audio.
- `1020 (1)(1).MP3`: **44.042s**, 44.1 kHz stereo MP3, peak approximately **−0.2 dBFS**, mean **−18.4 dBFS**. No meaningful long silences detected; optimize mix so background SFX/music do not compete. These are technical measurements, not a claim of subjective vocal quality.

## Raw video editorial locations (approx.)

| Original time | Observed | Editorial decision |
|---|---|---|
| 0–8s | Steam Fracture market/listing and scrolling | Use details |
| 8–14s | Switch to ChatGPT; shows earlier script | **Exclude** |
| 14–52s | Steam chart/book + purchase interface | Use, crop browser chrome |
| ~52–77s | Older Cologne 2026 portfolio and unrelated tabs | **Exclude** |
| ~77–90s | New TrueSkins portfolio and Fracture entry | Use relevant confirmations only |
| ~90–102.4s | CS2 inventory with multiple Fracture cases; item navigator 1/20 shown | Key proof shot |

## Curated proxy timeline

For file `public/assets/footage-curated.mp4` (silent, ~71.4s, 1600x900@24fps):

| Proxy | Raw source |
|---|---|
| 0–8s | 0–8s |
| 8–46s | 14–52s |
| 46–71.4s | 77–102.4s |

Scenes have hard cuts; use the footage as B-roll references or video layers, not as the final edit. Original master file has superior resolution for macro-crops. Keep it separately for final export if available.

## Proof / unconfirmed

- In-game inventory frame shows **20 Fracture Cases** (a `1/20` item navigator) by the end of recording.
- Steam marketplace footage shows approximate ask **40.61 RUB** and ~172k active *offers at that captured moment*. This is **not verified transaction execution** or live market value; do not show as day-1 purchase cost.
- The narrator's exact transcript has not been machine-transcribed; `docs/SCRIPT_REFERENCE.md` is only the last scripted variant before upload. Align subtitle text to the ACTUAL MP3 by listening.
- The first-day total cost remains **unverified**. `data/day01.json` sets it to null on purpose.
