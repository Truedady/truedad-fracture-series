# Captions

DO NOT generate hard-coded SRT from the script reference: the voice recording may differ.

Claude must listen to `public/assets/voiceover-day01.mp3`, create a word-timestamp transcription, export `day01.srt`, then implement synchronized motion-caption components. If no reliable audio recognition is available, ask for a human transcript rather than invent a subtitle file.
