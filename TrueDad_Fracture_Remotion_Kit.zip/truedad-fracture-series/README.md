# TrueDad — CS2 Daily Accumulation / Fracture Day 01

Private-first, reusable Remotion workspace for a vertical TrueDad experiment: buying **20 Fracture Cases on day 1**, then **+5 cases/day** for 30 days. Target: **2,775 cases**. This is a *story and editor starter*, not a completed render.

## Open in Claude Code / Claude Projects

1. Keep this project **PRIVATE**, especially if adding unedited captures or voice files.
2. Clone or open the folder; open `prompts/CLAUDE_MASTER_PROMPT.md` and send its contents to Claude.
3. Install Node.js (20+ recommended), then in this folder run `npm install` once.
4. Preview via `npm run dev`; render a first draft with `npm run render`.
5. If using an agent, let it apply the official Remotion skill and refine the project; **do not reinstall/scaffold Remotion for each episode**.
6. Confirm actual transaction spend and timestamps before publishing; fill null fields in `data/day01.json`.

**Assets included**

- `public/assets/voiceover-day01.mp3` — user-provided 44.04-second narration.
- `public/assets/footage-curated.mp4` — 71.4-second edited copy of user's horizontal 102.4s recording: irrelevant sections excluded, 1600x900 at 24fps; video is silent because voiceover is separate.
- `public/assets/proof/*.jpg` — relevant source screenshots cropped from original for precise visual reference.
- `prompts/CLAUDE_MASTER_PROMPT.md` — production brief with explicit QA requirements.
- `brand/STYLE_GUIDE.md` — reusable visual identity.
- `docs/SOURCE_AUDIT.md`, `docs/SHOT_LIST.md` — original timing maps and narrative guidance.
- `src/` — functional *starting point*, not final bespoke edit.

**Important**

All graphics that indicate financial data must derive from uploaded footage or verified values, and every illustrative chart must be visually labeled as such. Asking for users' investment outcome prediction is a creative hook, not financial advice. Do not claim investment returns or discounts that are not documented. Don't blur sponsored content identification if future paid collaborations are added.

## 30-day strategy

- Case: Fracture
- Day n purchase quantity: `20 + 5 * (n - 1)`
- Total after n days: `n * 20 + 5 * n * (n - 1) / 2`
- After 30 days: **2,775** cases
- No guarantee of gain; distinguish purchase price, current market ask and net realizable value after commission.

## Publishing outputs

1080 x 1920, 30 fps, H.264 MP4 (Rec.709, yuv420p), voice prominent with licensed sound design, burned-in *accurate* subtitles. Keep TikTok/Shorts safe areas. Target narration duration ~44.04s; do not pad to 60s.

## Caveat on GitHub

This repository template is prepared locally. Creating the **remote GitHub repository** is a separate step. A 25 MiB/browser-upload limit is why this kit uses a curated, compressed source video instead of the 50.8 MiB master. Preserve the master outside GitHub, or add via Git LFS if needed.
